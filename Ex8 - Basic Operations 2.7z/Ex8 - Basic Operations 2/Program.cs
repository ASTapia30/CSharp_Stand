﻿/*
Instructions
Find the difference between the square of the sum and the sum of the squares of the first N natural numbers.

The square of the sum of the first ten natural numbers is (1 + 2 + ... + 10)² = 55² = 3025.

The sum of the squares of the first ten natural numbers is 1² + 2² + ... + 10² = 385.

Hence the difference between the square of the sum of the first ten natural numbers and the 
sum of the squares of the first ten natural numbers is 3025 - 385 = 2640.**/


using System;

namespace Ex8___Basic_Operations_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DifferenceOfSquares.CalculateSquareOfSum(10));
            Console.WriteLine(DifferenceOfSquares.CalculateSumOfSquares(10));
            Console.WriteLine(DifferenceOfSquares.CalculateDifferenceOfSquares(10));
        }
    }

    public static class DifferenceOfSquares
    {
        public static int CalculateSquareOfSum(int max)
        {
            int sum = 0;
            int i;
            for (i = 1; i <= max; i++){
                sum = sum + i;
            }
            int res = Convert.ToInt32(Math.Pow(sum,2));
            return res;
        }

        public static int CalculateSumOfSquares(int max)
        {
            int sum = 0;
            int i;
            for (i = 1; i <= max; i++){
                sum = sum + Convert.ToInt32(Math.Pow(i,2));
            }
            return sum;
        }

        public static int CalculateDifferenceOfSquares(int max)
        {
            int res;
            res = DifferenceOfSquares.CalculateSquareOfSum(max) - DifferenceOfSquares.CalculateSumOfSquares(max);
            return res;
        }
    }
}
