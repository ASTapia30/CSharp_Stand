﻿using System;

namespace Ex2___Basic_Operations_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine(new Lasagna().ExpectedMinutesInOven()); // 40
            Console.WriteLine(new Lasagna().RemainingMinutesInOven(25)); // 15
            Console.WriteLine(new Lasagna().PreparationTimeInMinutes(1)); // 2
            Console.WriteLine(new Lasagna().PreparationTimeInMinutes(4)); // 8
            Console.WriteLine(new Lasagna().ElapsedTimeInMinutes(1, 30)); // 32
            Console.WriteLine(new Lasagna().ElapsedTimeInMinutes(4, 8)); // 16
        }
    }
}
