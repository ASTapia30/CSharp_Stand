﻿/*Instructions
    In this exercise you'll be processing log-lines.

    Each log line is a string formatted as follows: "[<LEVEL>]: <MESSAGE>".

    There are three different log levels:

    INFO
    WARNING
    ERROR
    You have several tasks, each of which will take a log line and ask you to do something with it.

    1. Allow retrieving the string after a specific substring
    Looking at the logs of the last month, you see that the test message is always 
    located after a specific substring. As you're anticipating having to extract the 
    test message sometime in the near future, you decide to create a helper method to help you with that.

        Implement the (static) LogAnalysis.SubstringAfter() extension method, that 
        takes in some string delimeter and returns the substring after the delimiter.

        var log = "[INFO]: File Deleted.";
        log.SubstringAfter(": "); // => returns "File Deleted."

    2. Allow retrieving the string in between two substrings
    On further inspection, you see that the log level is always located between square 
    brackets ([ and ]). As you're also anticipating having to extract the log level sometime 
    in the near future, you decide to create a another helper method to help you with that.

        Implement the (static) LogAnalysis.SubstringBetween() extension method that takes 
        in two string delimeters, and returns the substring that lies between the two delimeters.

        var log = "[INFO]: File Deleted.";
        log.SubstringBetween("[", "]"); // => returns "INFO"

    3. Parse message in a log
        Implement the (static) LogAnalysis.Message() extension method to return the 
        message contained in a log.

        var log = "[ERROR]: Missing ; on line 20.";
        log.Message(); // => returns "Missing ; on line 20."

    4. Parse log level in a log
        Implement the (static) LogAnalysis.LogLevel() extension method to return the
        log level of a log.

        var log = "[ERROR]: Missing ; on line 20.";
        log.LogLevel(); // => returns "ERROR"

*/

using System;

namespace Ex9___Extension_Methods
{
    class Program
    {
        static void Main(string[] args)
        {
            var log = "[INFO]: File Deleted.";
            Console.WriteLine(log.SubstringAfter(": "));
            Console.WriteLine(log.Message());
            Console.WriteLine(log.LogLevel());

            var log2 = "[INFO]: File Deleted.";
            Console.WriteLine(log2.SubstringBetween("[", "]"));
        }
    }

    public static class LogAnalysis
    {
        public static string SubstringAfter(this String str1, string str2)
        {
            int var = str1.IndexOf(str2);
            string res = str1.Substring(var+(str2.Length));
            return  res;
        }

        public static string SubstringBetween(this String str1, string str2, string str3)
        {
            int start = str1.IndexOf(str2);//0
            int end = str1.LastIndexOf(str3);//7
            int length = (end) - (start+1);//7 - 1
            string res = str1.Substring((start+1), length);//1,5
            return res;
        }

        public static string Message(this String str1)
        {
            string res = str1.SubstringAfter(": ");
            return  res;
        }

        public static string LogLevel(this String str1)
        {
            string res = str1.SubstringBetween("[", "]");
            return res;
        }
    }
}
