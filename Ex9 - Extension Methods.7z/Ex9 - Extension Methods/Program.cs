﻿using System;

namespace Ex9___Extension_Methods
{
    class Program
    {
        static void Main(string[] args)
        {
            var log = "[INFO]: File Deleted.";
            Console.WriteLine(log.SubstringAfter(": "));
            Console.WriteLine(log.Message());
            Console.WriteLine(log.LogLevel());

            var log2 = "[INFO]: File Deleted.";
            Console.WriteLine(log2.SubstringBetween("[", "]"));
        }
    }

    public static class LogAnalysis
    {
        public static string SubstringAfter(this String str1, string str2)
        {
            int var = str1.IndexOf(str2);
            string res = str1.Substring(var+(str2.Length));
            return  res;
        }

        public static string SubstringBetween(this String str1, string str2, string str3)
        {
            int start = str1.IndexOf(str2);//0
            int end = str1.LastIndexOf(str3);//7
            int length = (end) - (start+1);//7 - 1
            string res = str1.Substring((start+1), length);//1,5
            return res;
        }

        public static string Message(this String str1)
        {
            string res = str1.SubstringAfter(": ");
            return  res;
        }

        public static string LogLevel(this String str1)
        {
            string res = str1.SubstringBetween("[", "]");
            return res;
        }
    }
}
