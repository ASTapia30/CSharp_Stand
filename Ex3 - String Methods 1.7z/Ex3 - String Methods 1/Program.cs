﻿using System;

namespace Ex3___String_Methods_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(LogLine.Message("[ERROR]: Stack overflow")); // "Stack overflow"
            Console.WriteLine(LogLine.Message("[WARNING]: Disk almost full")); // "Disk almost full"
            Console.WriteLine(LogLine.Message("[WARNING]:   \tTimezone not set  \r\n")); // "Timezone not set"
            Console.WriteLine(LogLine.LogLevel("[ERROR]: Disk full")); // "error"
            Console.WriteLine(LogLine.LogLevel("[WARNING]: Unsafe password")); // "warning"
            Console.WriteLine(LogLine.Reformat("[ERROR]: Segmentation fault")); //"Segmentation fault (error)"
            Console.WriteLine(LogLine.Reformat("[INFO]: Disk defragmented")); //"Disk defragmented (info)"
        }
    }
}
