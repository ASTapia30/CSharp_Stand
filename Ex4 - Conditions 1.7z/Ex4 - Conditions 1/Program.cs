﻿using System;

namespace Ex4___Conditions_1
{
    class Program
    {
        static void Main(string[] args)
        {
            var knightIsAwake = true; 
            var archerIsAwake = false;
            var prisonerIsAwake = false;
            var petDogIsPresent = false;
            Console.WriteLine(QuestLogic.CanFastAttack(knightIsAwake));          
            Console.WriteLine(QuestLogic.CanSpy(knightIsAwake, archerIsAwake, prisonerIsAwake));
            Console.WriteLine(QuestLogic.CanFreePrisoner(knightIsAwake, archerIsAwake, prisonerIsAwake, petDogIsPresent));
        }
    }
}
