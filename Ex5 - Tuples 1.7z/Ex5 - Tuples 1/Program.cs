﻿    /**Instructions
This exercise has you analyze phone numbers.

You are asked to implement 2 features.

Phone numbers passed to the routines are guaranteed to be in the form NNN-NNN-NNNN e.g. 212-515-9876 and
non-null.

-->Task 1
    Analyze a phone number

    Your analysis should return 3 pieces of data

    An indication of whether the number has a New York dialing code ie. 212 as the first 3 digits
    An indication of whether the number is fake having 555 as a prefix code in positions 5 to 7 
    (numbering from 1)
    The last 4 digits of the number.
    Implement the (static) method PhoneNumber.Analyze() to produce the phone number info.

    PhoneNumber.Analyze("631-555-1234");
    // => (false, true, "1234")

-->Task 2
    Detect if a phone number has a fake prefix code (555)

    Implement the (static) method PhoneNumber.IsFake() to detect whether the phone number is fake 
    using the phone number info produced in task 1.

    PhoneNumber.IsFake(PhoneNumbers.Analyze("631-555-1234"));
    // => true

*/



using System;

namespace Ex5___Tuples_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(PhoneNumber.Analyze("631-502-1234")); // (false, false, "1234")
            Console.WriteLine(PhoneNumber.Analyze("631-555-1234")); // (false, true, "1234")
            Console.WriteLine(PhoneNumber.Analyze("212-502-1234")); // (true, false, "1234")
            Console.WriteLine(PhoneNumber.IsFake(PhoneNumber.Analyze("212-555-1234"))); // True
        }
    }

    public static class PhoneNumber
    {
        public static (bool IsNewYork, bool IsFake, string LocalNumber) Analyze(string phoneNumber)
        {
            bool IsNewYork1;
            bool IsFake1;
            string dcode_ver = phoneNumber.Substring(0,3);
            if (dcode_ver == "212"){
                IsNewYork1 = true;
            } else{
                IsNewYork1 = false;
            }

            string num_verif = phoneNumber.Substring(4,3);
            if (num_verif == "555"){
                IsFake1 = true;
            }else{
                IsFake1 = false;
            }

            string LocalNumber = phoneNumber.Substring(8,4);

            return (IsNewYork1, IsFake1, LocalNumber);
        }

        public static bool IsFake((bool IsNewYork, bool IsFake, string LocalNumber) phoneNumberInfo)
        {        
            return (phoneNumberInfo.Item2);
        }
    }

}
